package Projects.Project1;

public class Main {

    public static void main(String [] args){
        TreeManager test = new TreeManager();
        test.run();
    }
}
