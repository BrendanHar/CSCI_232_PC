package Labs.Lab9;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ScrapCode {
//    try {
//        File graphIn = new File(file);
//        if (!graphIn.exists()) {
//            System.out.println("Invalid input. Check your filename");
//        }
//        else {
//            Scanner s = new Scanner(graphIn);
//            Scanner count = new Scanner(graphIn);
//            int lines = 0;
//            count.nextLine();
//            while (count.hasNextLine()) {
//                count.nextLine();
//                lines++;
//            }
//            System.out.println("Number of edges: " + lines);
//            String[] text = new String[lines];
//            String input = "";
//            int size = s.nextInt();
//            int i = 0;
//            System.out.println("Number of Vertices in Graph: " + size);
//
//            while (s.hasNextLine()) {
//                input += s.nextLine();
//                input += "\n";
//            }
//
////                System.out.println(input);
//            text = input.split("\n");
//            System.out.println();
//            int[] test = new int[2];
//            for (int j = 0; j < lines + 1; j++){
//                test = text[j].split(",")
//                System.out.println(text[j]);
//            }
//
//        }
//    }
//        catch (
//    FileNotFoundException e) {
//        e.printStackTrace();
//    }
//    adjacencyList[Integer.parseInt(test[0])].add(test[1])

}
